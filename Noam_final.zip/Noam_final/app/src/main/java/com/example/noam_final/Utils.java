package com.example.noam_final;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuthException;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;


public class Utils
{

    public static void showSnackbar(View view, String message)
    {
        Snackbar.make(view, message, Snackbar.LENGTH_INDEFINITE)
                .setAction("OK", new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                    }
                })
                .show();
    }

    public static void showToast(Context context, String message)
    {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public static void setBackButton(ImageButton backButton, Activity activity)
    {
        backButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                activity.finish();
            }
        });
    }

    public static String getFirebaseAuthErrorMessage(Exception exception)
    {
        if (exception instanceof FirebaseAuthException)
        {
            String errorCode = ((FirebaseAuthException) exception).getErrorCode();
            switch (errorCode)
            {
                case "ERROR_INVALID_EMAIL":
                    return "Invalid Email Format.";
                case "ERROR_INVALID_CREDENTIAL":
                    return "Email Or Passowrd Is Incorrect.";
                case "ERROR_EMAIL_ALREADY_IN_USE":
                    return "This Email Is Already Registered.";
                case "ERROR_WEAK_PASSWORD":
                    return "Password Must Be At Least 6 Characters Long.";
            }
        }
        return "Unknown error occurred.";
    }

    public static String readRawTextFile(Context context, int resId)
    {
        InputStream inputStream = context.getResources().openRawResource(resId);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder content = new StringBuilder();
        String line;

        try
        {
            while ((line = reader.readLine()) != null)
            {
                content.append(line).append("\n");
            }
            reader.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return content.toString();
    }
}