package com.example.noam_final;

public class User
{
    private String username;
    private String email;
    private String joinDate;
    public User(String username, String email, String joinDate)
    {
        this.username = username;
        this.email = email;
        this.joinDate = joinDate;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getJoinDate()
    {
        return joinDate;
    }

}
